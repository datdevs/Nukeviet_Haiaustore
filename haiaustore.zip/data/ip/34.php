<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:19:59 GMT
 */

$ranges=array(570425344=>array(586153983,'US'),586153984=>array(586975999,'IE'),586976089=>array(586976089,'IE'),586976256=>array(587006719,'IE'),587006720=>array(587006975,'GB'),587006976=>array(587202559,'IE'));
