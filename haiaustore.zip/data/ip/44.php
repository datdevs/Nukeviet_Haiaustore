<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:20:03 GMT
 */

$ranges=array(738197504=>array(746786303,'US'),746786304=>array(746786559,'GB'),746786560=>array(746973439,'US'),746973440=>array(746973695,'ES'),746973696=>array(747175935,'US'),747175936=>array(747241471,'NL'),747241472=>array(747372543,'US'),747372544=>array(747438079,'SE'),747438080=>array(747671807,'US'),747671808=>array(747672063,'GB'),747672064=>array(750649855,'US'),750649856=>array(750650111,'AT'),750650112=>array(754974719,'US'));
