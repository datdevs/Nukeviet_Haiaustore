<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:20:03 GMT
 */

$ranges=array(654311424=>array(654311679,'CN'),654311680=>array(654311935,'AU'),654311936=>array(654376959,'CN'),654376960=>array(654442495,'TW'),654442496=>array(654573567,'JP'),654573568=>array(654835711,'KR'),654835712=>array(654999551,'TW'),654999552=>array(655001599,'CN'),655001600=>array(655359999,'TW'),655360000=>array(656408575,'KR'),656408576=>array(658505727,'PK'),658505728=>array(661454847,'CN'),661454848=>array(661487615,'HK'),661487616=>array(661520383,'SG'),661520384=>array(661651455,'JP'),661651456=>array(662700031,'KR'),662700032=>array(666894335,'CN'),666894336=>array(671088639,'ID'));
