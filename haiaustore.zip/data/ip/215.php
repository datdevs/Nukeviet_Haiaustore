<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:23:20 GMT
 */

$ranges=array(3607101440=>array(3623878655,'US'));
