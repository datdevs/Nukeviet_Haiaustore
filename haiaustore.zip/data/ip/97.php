<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:20:26 GMT
 */

$ranges=array(1627389952=>array(1632305151,'US'),1632305152=>array(1632321535,'CA'),1632321536=>array(1632354303,'US'),1632354304=>array(1632362495,'CA'),1632362496=>array(1634414591,'US'),1634414592=>array(1634418687,'CA'),1634418688=>array(1634447359,'US'),1634447360=>array(1634451455,'CA'),1634451456=>array(1634455551,'US'),1634455552=>array(1634460671,'CA'),1634460672=>array(1634467839,'US'),1634467840=>array(1634729983,'CA'),1634729984=>array(1644167167,'US'));
