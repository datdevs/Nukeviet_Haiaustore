<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:20:07 GMT
 */

$ranges=array(889192448=>array(897238054,'DE'),897238056=>array(905969663,'DE'));
