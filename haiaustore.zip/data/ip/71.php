<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:20:15 GMT
 */

$ranges=array(1191182336=>array(1191673855,'US'),1191673856=>array(1191706623,'CA'),1191706624=>array(1192232127,'US'),1192232128=>array(1192232159,'PA'),1192232160=>array(1192296447,'US'),1192296448=>array(1192361983,'CA'),1192361984=>array(1192427519,'US'),1192427520=>array(1192460287,'CA'),1192460288=>array(1192468479,'US'),1192468480=>array(1192476671,'CA'),1192476672=>array(1192488959,'US'),1192488960=>array(1192493055,'CA'),1192493056=>array(1207959551,'US'));
