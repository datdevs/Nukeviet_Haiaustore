<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:28:21 GMT
 */

$ranges = array('2802::/31'=>'CO','2802:2::/33'=>'CO','2802:2:8000::/35'=>'CO','2802:2:a000::/36'=>'BR','2802:2:b000::/36'=>'CO','2802:2:c000::/34'=>'CO','2802:3::/35'=>'PA','2802:3:2000::/35'=>'PE','2802:3:4000::/35'=>'MX','2802:3:6000::/35'=>'EC','2802:3:8000::/35'=>'BR','2802:3:a000::/35'=>'CO','2802:3:c000::/34'=>'CO','2802:8000::/24'=>'AR');
