<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:28:19 GMT
 */

$ranges = array('2609::/22'=>'US','2609:4000::/22'=>'US','2609:8000::/22'=>'US','2609:a000::/22'=>'US','2609:c000::/22'=>'US','2609:e000::/22'=>'US');
