<?php

/**
 * NukeViet Content Management System
 * @version 4.x
 * @author VINADES.,JSC <contact@vinades.vn>
 * @copyright (C) 2009-2021 VINADES.,JSC. All rights reserved
 * @license GNU/GPL version 2 or any later version
 * @see https://github.com/nukeviet The NukeViet CMS GitHub project
 */

if (!defined('NV_MAINFILE')) {
    exit('Stop!!!');
}

$cache = 'a:22:{s:14:"/CHANGELOG.txt";s:1:"1";s:14:"/COPYRIGHT.txt";s:1:"1";s:8:"/LICENSE";s:1:"1";s:10:"/README.md";s:1:"1";s:7:"/admin/";s:1:"0";s:8:"/api.php";s:1:"1";s:8:"/assets/";s:1:"1";s:14:"/composer.json";s:1:"0";s:11:"/config.php";s:1:"1";s:6:"/data/";s:1:"0";s:10:"/error.php";s:1:"1";s:12:"/favicon.ico";s:1:"1";s:10:"/includes/";s:1:"0";s:10:"/index.php";s:1:"1";s:9:"/install/";s:1:"0";s:9:"/modules/";s:1:"0";s:11:"/robots.php";s:1:"0";s:11:"/robots.txt";s:1:"1";s:8:"/themes/";s:1:"1";s:9:"/uploads/";s:1:"1";s:8:"/vendor/";s:1:"1";s:11:"/web.config";s:1:"0";}';

$cache_other = 'a:2:{s:7:"/users/";i:0;s:12:"/statistics/";i:0;}';